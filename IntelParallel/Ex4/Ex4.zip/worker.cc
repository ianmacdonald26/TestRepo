#include <mkl.h>
#include <hbwmalloc.h>


//implement scratch buffer on HBM and compute FFTs, refer instructions on Lab page
void runFFTs( const size_t fft_size, const size_t num_fft, MKL_Complex8 *data, DFTI_DESCRIPTOR_HANDLE *fftHandle) {
  const int long buff_size=fft_size;
  MKL_Complex8 *buff;
  hbw_posix_memalign((void**)&buff,4096,sizeof(MKL_Complex8)*buff_size);
  for(size_t i = 0; i < num_fft; i++) {
#pragma omp parallel for
    for (size_t k=0; k<fft_size; k++) {
      buff[k]=data[i*fft_size+k];
      }
    DftiComputeForward (*fftHandle, buff);
#pragma omp parallel for
    for (size_t k=0; k<fft_size; k++) {
      data[i*fft_size+k]=buff[k];
      }
  }
  hbw_free(buff);
}
